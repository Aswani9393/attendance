package Repository;

public interface JpaRepository<T, T1> {
}
